import pandas as pd
import os

if not os.path.exists('results'):
    os.makedirs('results')

df = pd.read_csv('COVIDiSTRESS_May_30_cleaned_final.csv', encoding='ISO-8859-1')

df.columns = df.columns.str.strip()

columns = ['Dem_gender', 'Dem_age', 'Country', 'Dem_edu', 'Dem_employment',
           'Expl_media_1', 'Expl_media_2', 'Expl_media_3', 'Expl_media_4', 'Expl_media_5', 'Expl_media_6',
           'Trust_countrymeasure',
           'OECD_insititutions_1', 'OECD_insititutions_2', 'OECD_insititutions_3', 'OECD_insititutions_4', 'OECD_insititutions_5', 'OECD_insititutions_6',
           'OECD_people_1', 'OECD_people_2']

df_filtered = df[columns]

valid_genders = ['Male', 'Female', 'Other/would rather not say']
df_filtered = df_filtered[df_filtered['Dem_gender'].isin(valid_genders)]

numeric_columns = ['Dem_age', 'Expl_media_1', 'Expl_media_2', 'Expl_media_3', 
                   'Expl_media_4', 'Expl_media_5', 'Expl_media_6', 
                   'Trust_countrymeasure',
                   'OECD_insititutions_1', 'OECD_insititutions_2', 'OECD_insititutions_3', 
                   'OECD_insititutions_4', 'OECD_insititutions_5', 'OECD_insititutions_6',
                   'OECD_people_1', 'OECD_people_2']
df_filtered[numeric_columns] = df_filtered[numeric_columns].apply(pd.to_numeric, errors='coerce')
df_cleaned = df_filtered.dropna()


df_cleaned.to_csv('results/cleaned_COVIDiSTRESS_May_30_with_media_OECD.csv', index=False)
