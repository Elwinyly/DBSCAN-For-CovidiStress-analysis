import pandas as pd


data = pd.read_csv('cleaned_COVIDiSTRESS_May_30_with_media_OECD.csv', encoding='ISO-8859-1')


unique_genders = data['Dem_gender'].unique()
unique_countries = data['Country'].unique()
unique_education = data['Dem_edu'].unique()
unique_employment = data['Dem_employment'].unique()


print("Genders:", unique_genders)
print("Countries:", unique_countries)
print("Education Levels:", unique_education)
print("Employment Types:", unique_employment)