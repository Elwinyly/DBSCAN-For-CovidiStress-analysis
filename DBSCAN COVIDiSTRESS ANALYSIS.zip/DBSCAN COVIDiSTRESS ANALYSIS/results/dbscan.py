import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt  # For plotting
import seaborn as sns  # For enhanced visualizations

# Function to save plots to the current directory
def save_plot(filename):
    """
    Saves the current matplotlib figure to the current working directory.

    Parameters:
    - filename (str): The name of the file to save the plot as.
    """
    current_dir = os.getcwd()
    save_path = os.path.join(current_dir, filename)
    plt.savefig(save_path, bbox_inches='tight')
    print(f"Plot saved as: {save_path}")

# Step 1: Load the data
file_path = "processed_data_with_encoded_only1.csv"  # Replace with your file path
data = pd.read_csv(file_path)

# Step 2: Handle missing values by imputing with the mean
imputer = SimpleImputer(strategy='mean')
data_imputed = imputer.fit_transform(data)

# Step 3: Scale the data to standardize features
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data_imputed)

# Step 4: Perform DBSCAN clustering
dbscan = DBSCAN(eps=3, min_samples=40)
clusters = dbscan.fit_predict(data_scaled)

# Step 5: Assign cluster labels to the original dataframe
data['Cluster'] = clusters

# Step 6: Calculate and print the mean of each cluster
cluster_means = data.groupby('Cluster').mean()
print("Cluster Means:")
print(cluster_means)

# Step 7: Save the cluster means to a CSV file
cluster_means.to_csv("cluster_means.csv")  # Saves to current directory
print("Cluster means saved to 'cluster_means.csv'.")

# Step 8: Visualize the number of points in each cluster using Matplotlib
# Count the number of points per cluster
cluster_counts = data['Cluster'].value_counts().sort_index()

# Define a color palette with as many colors as clusters
palette = sns.color_palette("viridis", len(cluster_counts))

# Set up the bar plot using Matplotlib
plt.figure(figsize=(10, 6))
bars = plt.bar(
    x=cluster_counts.index.astype(str),
    height=cluster_counts.values,
    color=palette
)

# Add titles and labels
plt.title('Number of Points in Each Cluster', fontsize=16)
plt.xlabel('Cluster Label', fontsize=14)
plt.ylabel('Number of Points', fontsize=14)

# Annotate bars with counts
for bar in bars:
    height = bar.get_height()
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        height + max(cluster_counts.values) * 0.01,
        f'{int(height)}',
        ha='center',
        va='bottom',
        fontsize=12
    )

# Save the plot as an image file to the current directory
save_plot("cluster_counts.png")

# Display the plot
plt.show()

# -------------------- Added Visualizations --------------------

# Visualization 1: PCA-Reduced 2D Scatter Plot
# Step 9: Reduce dimensionality to 2D using PCA for visualization
pca = PCA(n_components=2)
data_pca = pca.fit_transform(data_scaled)
pca_df = pd.DataFrame(data_pca, columns=['PC1', 'PC2'])
pca_df['Cluster'] = clusters

# Plot the PCA scatter plot
plt.figure(figsize=(10, 8))
sns.scatterplot(
    x='PC1', y='PC2',
    hue='Cluster',
    palette='viridis',
    data=pca_df,
    legend='full',
    alpha=0.6
)
plt.title('DBSCAN Clustering Results (PCA Reduced)', fontsize=16)
plt.xlabel('Principal Component 1', fontsize=14)
plt.ylabel('Principal Component 2', fontsize=14)
plt.legend(title='Cluster', fontsize=12, title_fontsize=13)

# Save the PCA scatter plot to the current directory
save_plot("dbscan_pca_scatter.png")

# Display the plot
plt.show()

# Visualization 2: Cluster Means Heatmap
# Step 10: Visualize cluster means with a heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(cluster_means.transpose(), annot=True, cmap='viridis')
plt.title('Heatmap of Cluster Feature Means', fontsize=16)
plt.xlabel('Cluster', fontsize=14)
plt.ylabel('Features', fontsize=14)

# Save the heatmap to the current directory
save_plot("cluster_means_heatmap.png")

# Display the plot
plt.show()

# Visualization 3: Optional - Convex Hull around Clusters (Advanced Visualization)
# This visualization is optional and provides boundaries around clusters
from scipy.spatial import ConvexHull

plt.figure(figsize=(10, 8))
sns.scatterplot(
    x='PC1', y='PC2',
    hue='Cluster',
    palette='viridis',
    data=pca_df,
    legend='full',
    alpha=0.6
)
plt.title('DBSCAN Clustering Results with Convex Hulls (PCA Reduced)', fontsize=16)
plt.xlabel('Principal Component 1', fontsize=14)
plt.ylabel('Principal Component 2', fontsize=14)
plt.legend(title='Cluster', fontsize=12, title_fontsize=13)

# Draw convex hulls for each cluster (excluding noise)
unique_clusters = cluster_means.index.tolist()
unique_clusters.remove(-1) if -1 in unique_clusters else None

for cluster in unique_clusters:
    subset = pca_df[pca_df['Cluster'] == cluster]
    if len(subset) >= 3:  # ConvexHull requires at least 3 points
        hull = ConvexHull(subset[['PC1', 'PC2']])
        hull_points = subset.iloc[hull.vertices]
        plt.plot(
            hull_points['PC1'],
            hull_points['PC2'],
            color=palette[cluster % len(palette)],
            linewidth=2,
            label=f'Cluster {cluster} Boundary'
        )

# To avoid duplicate legend entries
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))
plt.legend(by_label.values(), by_label.keys(), title='Cluster')

# Save the plot with convex hulls to the current directory
save_plot("dbscan_convex_hull.png")

# Display the plot
plt.show()

# --------------------------------------------------------------
