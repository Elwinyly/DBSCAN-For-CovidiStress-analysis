import pandas as pd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, OrdinalEncoder

# 读取数据
data = pd.read_csv("cleaned_COVIDiSTRESS_May_30_with_media_OECD.csv")

# 删除包含 'Uninformative response' 的行
data = data[data['Dem_edu'] != 'Uninformative response']

# 1. 性别编码映射
gender_encoder = LabelEncoder()
data['Gender_Encoded'] = gender_encoder.fit_transform(data['Dem_gender'])
gender_mapping = dict(zip(gender_encoder.classes_, gender_encoder.transform(gender_encoder.classes_)))
print("Gender Mapping:", gender_mapping)

# 2. 国籍编码映射
country_encoder = OneHotEncoder(sparse_output=False, drop='first')
country_encoded = country_encoder.fit_transform(data[['Country']])
country_mapping = country_encoder.categories_
country_encoded_df = pd.DataFrame(country_encoded, columns=country_mapping[0][1:])
print("Country Categories:", country_mapping)

# 3. 学历编码映射
education_order = ['Up to 6 years of school', 'Up to 9 years of school',
                   'Up to 12 years of school', 'Some College, short continuing education or equivalent',
                   'College degree, bachelor, master', 'PhD/Doctorate']
education_encoder = OrdinalEncoder(categories=[education_order])
data['Education_Encoded'] = education_encoder.fit_transform(data[['Dem_edu']])
education_mapping = {level: index for index, level in enumerate(education_order)}
print("Education Mapping:", education_mapping)

# 4. 职业编码映射
employment_encoder = OneHotEncoder(sparse_output=False, drop='first')
employment_encoded = employment_encoder.fit_transform(data[['Dem_employment']])
employment_mapping = employment_encoder.categories_
employment_encoded_df = pd.DataFrame(employment_encoded, columns=employment_mapping[0][1:])
print("Employment Categories:", employment_mapping)

# 删除原始的非数值列并替换为数值化的列
data.drop(['Dem_gender', 'Country', 'Dem_edu', 'Dem_employment', ], axis=1, inplace=True)

# 合并编码后的列与其他数值列
processed_df = pd.concat([data, employment_encoded_df, data[['Gender_Encoded']], data[['Education_Encoded']]], axis=1)

# 删除含有NaN值的行
df_cleaned = processed_df.dropna()

# 保存处理后的数据为 CSV 文件
df_cleaned.to_csv("processed_data_with_encoded_only1.csv", index=False)

# 判断文件是否成功保存
import os
if os.path.exists("processed_data_with_encoded_only.csv"):
    print("Processed data with encoded features has been saved to 'processed_data_with_encoded_only.csv'.")
else:
    print("Failed to save the processed data.")
