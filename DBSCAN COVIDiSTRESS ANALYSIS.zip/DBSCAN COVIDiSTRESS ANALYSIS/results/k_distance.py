# 导入必要的库
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

# 读取CSV文件
df = pd.read_csv('processed_data_with_encoded_only1.csv')

# 删除含有NaN值的行
df_cleaned = df.dropna()

# 标准化数据
scaler = StandardScaler()
df_scaled = scaler.fit_transform(df_cleaned)

# 使用K近邻算法计算每个数据点到第4个最近邻点的距离
neighbors = NearestNeighbors(n_neighbors=4)
neighbors_fit = neighbors.fit(df_scaled)
distances, indices = neighbors_fit.kneighbors(df_scaled)

# 排序距离以找到膝盖点
distances_sorted = np.sort(distances[:, 3])  # 第4近邻点的距离
plt.figure(figsize=(8, 6))
plt.plot(distances_sorted)
plt.title('K-distance Graph')
plt.xlabel('Data Points sorted by distance to 4th nearest neighbor')
plt.ylabel('4th Nearest Neighbor Distance')
plt.grid(True)
plt.show()
